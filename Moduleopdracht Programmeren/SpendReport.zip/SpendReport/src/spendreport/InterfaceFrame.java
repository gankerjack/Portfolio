package spendreport;

import javax.swing.JFrame;

/**
 *
 * @author Sebastiaan Crisan
 */
public class InterfaceFrame extends JFrame {

    /**
     *
     * @param text
     * @param width
     * @param height
     */
    public InterfaceFrame(String text, int width, int height) {
        this.setTitle(text);
        this.setSize(width, height);
    }
}
