package spendreport;

import java.time.LocalDate;

/**
 *
 * @author Sebastiaan Crisan
 */
public class Client {

    private String name;
    private double spend;

    /**
     *
     * @param name
     */
    public Client(String name) {
        this.name = name;
        this.spend = 0;
    }

    /**
     *
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     *
     * @return
     */
    public double getSpend() {
        return spend;
    }

    /**
     *
     * @return
     */
    public double calcProfit() {
        double rate = 0.15;
        return spend * rate;
    }

    /**
     *
     * @param days
     */
    public void addSpend(int days) {
        RandomNumberGen test = new RandomNumberGen();
        double randomSpend = test.randomSpend();
        spend = spend + randomSpend * days;
        //System.out.println("Spend added: " + randomSpend + "\n Total spend: " + spend);
    }

    /**
     *
     */
    public void resetSpend() {
        this.spend = 0;
    }

    /**
     *
     * @param profit
     * @param datePanel
     * @return
     */
    public double calcExtrapolatedProfit(double profit, DatePanel datePanel) {
        int currentQuarter = datePanel.getCurrentQuarter();
        LocalDate currentDate = datePanel.getCurrentDate();
        DaysCalculator daysCalculator = new DaysCalculator(currentDate, currentQuarter);
        int daysInQuarter = daysCalculator.getDaysInQuarter();
        int daysRunning = daysCalculator.getDaysRunning();
        if (daysRunning != 0) {
            return spend * daysInQuarter / daysRunning;
        } else {
            return 0;
        }
    }
}
