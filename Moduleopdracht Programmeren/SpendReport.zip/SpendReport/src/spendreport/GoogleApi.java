package spendreport;

import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;
/*
 * Functions as placeholder of the Google API. Contains 
 * method that returns a list of clients and client data.
 */

/**
 *
 * @author Sebastiaan Crisan
 */
public class GoogleApi {

    private String database;
    private File clientNames;
    private Scanner scanner;
    private String clientName;
    private Client client;

    /**
     *
     * @param input
     */
    public GoogleApi(String input) {
        this.database = input;
        System.out.println("Accessed Google API!");
    }

    /**
     *
     * @return
     */
    public ArrayList<Client> getClientList() {
        this.clientNames = new File(database);
        ArrayList<Client> clientList = new ArrayList<>();
        try {
            this.scanner = new Scanner(clientNames);
            while (scanner.hasNextLine()) {
                this.clientName = scanner.nextLine();
                this.client = new Client(clientName);
                clientList.add(client);
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(GoogleApi.class.getName()).log(Level.SEVERE, null, ex);
        }
        return clientList;
    }
}
