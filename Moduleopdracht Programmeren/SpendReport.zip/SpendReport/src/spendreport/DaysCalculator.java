package spendreport;

import java.time.Duration;
import java.time.LocalDate;
import java.time.Month;

/**
 *
 * @author Sebastiaan Crisan
 */
public class DaysCalculator {

    private int endMonth, endDay, endYear, beginMonth, beginDay, beginYear, daysInQuarter, daysRunning;
    private LocalDate beginOfQuarter;
    private LocalDate endOfQuarter;

    /**
     *
     * @param date
     * @param quarter
     */
    public DaysCalculator(LocalDate date, int quarter) {
        this.endMonth = quarter * 3;
        this.endDay = Month.of(endMonth).length(true);
        this.endYear = date.getYear();
        this.beginMonth = endMonth - 2;
        this.beginDay = 1;
        this.beginYear = date.getYear();
        this.beginOfQuarter = LocalDate.of(beginYear, beginMonth, beginDay);
        this.endOfQuarter = LocalDate.of(endYear, endMonth, endDay);
        this.daysInQuarter = (int) Duration.between(endOfQuarter.atTime(0, 0), beginOfQuarter.atTime(0, 0)).toDays();
        this.daysRunning = (int) Duration.between(date.atTime(0, 0), beginOfQuarter.atTime(0, 0)).toDays();
    }

    /**
     *
     * @return
     */
    public int getDaysInQuarter() {
        return this.daysInQuarter;
    }

    /**
     *
     * @return
     */
    public int getDaysRunning() {
        return this.daysRunning;
    }
}
