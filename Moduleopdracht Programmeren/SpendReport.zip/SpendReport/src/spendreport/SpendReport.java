package spendreport;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class SpendReport {

    private static final int height = 720;
    private static final int width = 1024;
    private static final Object colNames[] = {"Name", "Spend", "Profit (15%)", "Extrapolated Profit"};
    private static final String titleText = "Spend Report";
    private InterfaceFrame frame;
    private OneColGrid layout;
    private CustomTableModel customTableModel;
    private JTable table;
    private JScrollPane scrollPane;
    private DatePanel datePanel;
    private ButtonPanel buttonPanel;

    public SpendReport(ArrayList<Client> clientList) {

        //create the frame  
        this.frame = new InterfaceFrame(titleText, width, height);
        frame.setDefaultCloseOperation(InterfaceFrame.EXIT_ON_CLOSE);

        //create the grid layout and add it to the frame (1 col 3 rows)
        this.layout = new OneColGrid();
        frame.setLayout(layout);

        //create the table with non editable cells for the user
        this.customTableModel = new CustomTableModel(null, colNames, clientList);
        this.table = new JTable(customTableModel);
        this.scrollPane = new JScrollPane(table);

        //create date panel
        this.datePanel = new DatePanel();

        //create button panel
        this.buttonPanel = new ButtonPanel();

        //set action listeners for button panel
        buttonPanel.addActionListeners(new ActionListener() {
            private String action;
            private String dateString;
            private int days;

            @Override
            public void actionPerformed(ActionEvent ae) {
                this.action = ae.getActionCommand();
                switch (action) {
                    case "increaseDay":
                        this.days = 1;
                        this.dateString = datePanel.increaseDays(days);
                        datePanel.setDate(dateString);
                        customTableModel.updateTable(days, datePanel);
                        break;
                    case "increaseWeek":
                        this.days = 7;
                        this.dateString = datePanel.increaseDays(days);
                        datePanel.setDate(dateString);
                        customTableModel.updateTable(days, datePanel);
                        break;
                    case "increaseMonth":
                        this.dateString = datePanel.increaseMonth(1);
                        datePanel.setDate(dateString);
                        this.days = datePanel.daysBetweenDates(datePanel.getCurrentDate(), datePanel.getPreviousDate());
                        customTableModel.updateTable(days, datePanel);
                        break;
                    case "increaseRandom":
                        this.days = new RandomNumberGen().randomInt();
                        this.dateString = datePanel.increaseDays(days);
                        datePanel.setDate(dateString);
                        customTableModel.updateTable(days, datePanel);
                        break;
                }
            }
        });

        //add dates, table and button panel to frame
        frame.add(scrollPane);
        frame.add(datePanel);
        frame.add(buttonPanel);

        //set the frame visible
        frame.setVisible(true);
    }
}
