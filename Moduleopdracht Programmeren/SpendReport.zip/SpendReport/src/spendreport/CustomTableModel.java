package spendreport;

import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Sebastiaan Crisan
 */
public class CustomTableModel extends DefaultTableModel {

    private ArrayList<Client> clientList;
    private String name;

    private int currentRow;
    private int lastUpdatedQuarter;
    private int currentQuarter;
    private double clientSpend;
    private double clientProfit;
    private double extrapolatedProfit;

    /**
     *
     * @param rowData
     * @param colNames
     * @param input
     */
    public CustomTableModel(Object rowData[][], Object colNames[], ArrayList<Client> input) {
        super(rowData, colNames);
        this.clientList = input;
        initTable();
    }

    @Override
    public boolean isCellEditable(int row, int col) {
        return false;
    }

    /**
     *
     */
    public void initTable() {
        //initialize the table with client names, and default values of 0 for spend, profit and extrapolated spend

        for (Client client : clientList) {
            this.name = client.getName();
            Object[] row = {name, 0, 0, 0};
            this.addRow(row);
        }
    }

    /**
     *
     * @param days
     * @param datePanel
     */
    public void updateTable(int days, DatePanel datePanel) {
        this.currentRow = 0;

        this.lastUpdatedQuarter = datePanel.getLastUpdatedQuarter();
        //System.out.println("Previous iteration quarter: " + lastUpdatedQuarter);
        this.currentQuarter = datePanel.getCurrentQuarter();
        //System.out.println("Actual quarter: " + currentQuarter);
        datePanel.setLastUpdatedQuarter();

        for (Client client : clientList) {
            if (datePanel.isNewQuarter(lastUpdatedQuarter, currentQuarter)) {
                //System.out.println("New quarter so reset spend");
                client.resetSpend();
            }
            client.addSpend(days);
            clientSpend = client.getSpend();
            clientProfit = client.calcProfit();
            extrapolatedProfit = client.calcExtrapolatedProfit(clientProfit, datePanel);
            this.setValueAt("€ " + Math.round(100.0 * clientSpend) / 100.0, currentRow, 1);
            this.setValueAt("€ " + Math.round(100.0 * clientProfit) / 100.0, currentRow, 2);
            this.setValueAt("€ " + Math.round(100.0 * extrapolatedProfit) / 100.0, currentRow, 3);
            currentRow++;
        }
    }
}
