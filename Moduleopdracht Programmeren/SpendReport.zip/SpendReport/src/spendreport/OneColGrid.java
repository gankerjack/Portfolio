package spendreport;

import java.awt.GridLayout;

/**
 *
 * @author Sebastiaan Crisan
 */
public class OneColGrid extends GridLayout {

    private static final int rowAmount = 3;
    private static final int colAmount = 1;

    /**
     *
     */
    public OneColGrid() {
        this.setRows(rowAmount);
        this.setColumns(colAmount);
    }
}
