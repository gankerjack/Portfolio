package spendreport;

import java.util.ArrayList;

/**
 *
 * @author Sebastiaan Crisan
 */
public class Main {

    /**
     *
     * @param args
     */
    public static void main(String[] args) {
        String databasePath = "Database.txt";
        GoogleApi googleApi = new GoogleApi(databasePath);
        ArrayList<Client> clientList = googleApi.getClientList();
        SpendReport spendReport = new SpendReport(clientList);

    }
}
