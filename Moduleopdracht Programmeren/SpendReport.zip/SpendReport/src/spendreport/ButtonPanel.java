package spendreport;

import java.awt.event.ActionListener;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Sebastiaan Crisan
 */
public class ButtonPanel extends JPanel {

    //init buttons
    private final JButton dayButton, weekButton, monthButton, randomButton;

    /**
     *
     */
    public ButtonPanel() {
        this.dayButton = new JButton("Next Day");
        this.weekButton = new JButton("Next Week");
        this.monthButton = new JButton("Next Month");
        this.randomButton = new JButton("Increase Random");
        this.add(dayButton);
        this.add(weekButton);
        this.add(monthButton);
        this.add(randomButton);
    }

    /**
     *
     * @param al
     */
    public void addActionListeners(ActionListener al) {
        this.dayButton.setActionCommand("increaseDay");
        this.dayButton.addActionListener(al);

        this.weekButton.setActionCommand("increaseWeek");
        this.weekButton.addActionListener(al);

        this.monthButton.setActionCommand("increaseMonth");
        this.monthButton.addActionListener(al);

        this.randomButton.setActionCommand("increaseRandom");
        this.randomButton.addActionListener(al);
    }
}
