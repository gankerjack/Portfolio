package spendreport;

import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.time.*;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author Sebastiaan Crisan
 */
public class DatePanel extends JPanel {

    private RandomNumberGen randomNumberGen;
    private LocalDate currentDate;
    private LocalDate previousDate;
    private DateTimeFormatter formatter;
    private JLabel currentDateLabel;
    private JLabel currentQuarterLabel;
    private BorderLayout panelLayout;
    private String currentDateString;
    private int currentQuarter;
    private int lastUpdatedQuarter;
    private int currentMonth;

    /**
     *
     */
    public DatePanel() {
        //has a border layout
        this.panelLayout = new BorderLayout();
        this.setLayout(panelLayout);

        //date object and string for current date, and string for current quarter
        //will be shown in labels and these will be added to the borderlayout
        this.currentQuarter = 1;
        this.lastUpdatedQuarter = 1;
        this.currentDate = LocalDate.of(2019, 1, 1);
        this.formatter = DateTimeFormatter.ofPattern("dd MM yyyy");
        this.currentDateString = formatter.format(currentDate);
        this.currentDateLabel = new JLabel("Current date: " + currentDateString);
        this.currentQuarterLabel = new JLabel("Current quarter: " + currentQuarter);

        this.add(currentDateLabel, BorderLayout.NORTH);
        this.add(currentQuarterLabel, BorderLayout.CENTER);

        //init random number gen
        this.randomNumberGen = new RandomNumberGen();
    }

    /**
     *
     * @return
     */
    public LocalDate getCurrentDate() {
        System.out.println("Current date: " + currentDate);
        return this.currentDate;
    }

    /**
     *
     * @param days
     * @return
     */
    public String increaseDays(int days) {
        this.currentDate = currentDate.plusDays(days);
        return "Current date: " + formatter.format(currentDate);
    }

    /**
     *
     * @param month
     * @return
     */
    public String increaseMonth(int month) {
        this.previousDate = currentDate;
        this.currentDate = currentDate.plusMonths(month);
        return "Current date: " + formatter.format(currentDate);
    }

    /**
     *
     * @param dateString
     */
    public void setDate(String dateString) {
        this.currentDateLabel.setText(dateString);
        this.currentMonth = currentDate.getMonth().getValue();
        this.currentQuarter = (currentMonth + 2) / 3;
        this.currentQuarterLabel.setText("Current quarter: " + currentQuarter);
    }

    /**
     *
     * @return
     */
    public int getCurrentQuarter() {
        return this.currentQuarter;
    }

    /**
     *
     * @param quarter
     */
    public void setQuarter(int quarter) {
        this.currentQuarter = quarter;
    }

    /**
     *
     */
    public void setLastUpdatedQuarter() {
        this.lastUpdatedQuarter = currentQuarter;
    }

    /**
     *
     * @return
     */
    public int getLastUpdatedQuarter() {
        return lastUpdatedQuarter;
    }

    /**
     *
     * @param previous
     * @param current
     * @return
     */
    public boolean isNewQuarter(int previous, int current) {
        return previous != current;
    }

    /**
     *
     * @param previous
     * @param current
     * @return
     */
    public int daysBetweenDates(LocalDate previous, LocalDate current) {
        //this only works if you increment by 1 month max!
        if (!isNewQuarter(lastUpdatedQuarter, currentQuarter)) {
            return (int) Duration.between(current.atTime(0, 0), previous.atTime(0, 0)).toDays();
        } else {
            return current.getDayOfMonth();
        }
    }

    /**
     *
     * @return
     */
    public LocalDate getPreviousDate() {
        System.out.println("Previous date: " + previousDate);
        return this.previousDate;
    }

}
