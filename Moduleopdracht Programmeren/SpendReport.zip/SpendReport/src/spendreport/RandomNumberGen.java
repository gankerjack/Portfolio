package spendreport;

import java.util.Random;

/**
 *
 * @author Sebastiaan Crisan
 */
public class RandomNumberGen extends Random {

    /**
     *
     */
    public RandomNumberGen() {

    }

    /**
     *
     * @return
     */
    public int randomInt() {
        return this.nextInt(27);
    }

    /**
     *
     * @return
     */
    public double randomSpend() {
        int randomInt = this.nextInt(1000);
        return randomInt * this.nextDouble();
    }
}
